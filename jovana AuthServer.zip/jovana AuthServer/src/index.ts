import "reflect-metadata";
import { createConnection, getRepository } from "typeorm";
import express from "express";
import cors from "cors";
import jwt from "jsonwebtoken";
import { User } from "./entity/User";

createConnection().then((conection) => {
  const userRepository = getRepository(User);

  const app = express();
  app.use(cors());

  app.use(express.json());

  app.post("/login", (request, response) => {
    const username = request.body.username;
    const password = request.body.password;
    userRepository
      .find({
        where: {
          sifra: password,
          username: username,
        },
      })
      .then((users) => {
        if (users.length !== 1) {
          response.sendStatus(400);
          return;
        }
        const user = users[0];
        const access_token = jwt.sign(
          { ...user, id: parseInt(user.id as any) },
          process.env.ACCESS_TOKEN_SECRET as string,
          { expiresIn: "5s" }
        );
        const refresh_token = jwt.sign(
          { ...user, id: parseInt(user.id as any) },
          process.env.REFRESH_TOKEN_SECRET as string
        );
        response.json({
          user: user,
          access_token: access_token,
          refresh_token: refresh_token,
        });
      });
  });

  app.post("/register", async (request, response) => {
    const user = request.body as Partial<User>;
    const tempUsers = await userRepository.find({
      where: { username: user.username },
    });
    if (tempUsers.length > 0) {
      response.sendStatus(400);
      return;
    }
    const id = (await userRepository.insert(user)).identifiers[0].id;
    const newUser = (await userRepository.findOne(id)) as User;
    const access_token = jwt.sign(
      { ...newUser, id: parseInt(id) },
      process.env.ACCESS_TOKEN_SECRET as string,
      { expiresIn: "5s" }
    );
    const refresh_token = jwt.sign(
      { ...newUser, id: parseInt(id) },
      process.env.REFRESH_TOKEN_SECRET as string
    );

    response.json({
      user: newUser,
      access_token: access_token,
      refresh_token: refresh_token,
    });
  });
  app.post("/token", (request, response) => {
    const refreshToken = request.body.token;
    jwt.verify(
      refreshToken,
      process.env.REFRESH_TOKEN_SECRET as string,
      (err: any, user: any) => {
        if (err) {
          response.sendStatus(403);
          return;
        }
        const newUser: Partial<User> = {
          id: user.id,
          ime: user.ime,
          prezime: user.prezime,
          username: user.username,
        };
        const access_token = jwt.sign(
          newUser,
          process.env.ACCESS_TOKEN_SECRET as string,
          { expiresIn: "5s" }
        );
        response.json({
          user: newUser,
          access_token: access_token,
        });
      }
    );
  });

  app.listen(4000, () => console.log("App is listening"));
});
