import { getRepository } from "typeorm";
import Adresa from "../entity/adresa";
import Drzava from "../entity/drzava";
import Klijent from "../entity/klijent";
import Mesto from "../entity/mesto";
import Proizvod from "../entity/proizvod";
import Ugovor from "../entity/ugovor";

export const res = {
    adrese() {
        return getRepository(Adresa).find();
    },
    drzave() {
        return getRepository(Drzava).find();
    },
    mesta() {
        return getRepository(Mesto).find()
    },
    klijenti() {
        return getRepository(Klijent).find();
    },
    proizvodi() {
        return getRepository(Proizvod).find();
    },
    async ugovori() {
        const ugovori = await getRepository(Ugovor).find();
        return ugovori.map(element => {
            return { ...element, datum: element.datum.toISOString() }
        });
    },
    ugovor(parent, args, context, info) {
        const id = args.id;
        return getRepository(Ugovor).findOne(id);
    }

}

export default res;