import { FindConditions, getManager, getRepository } from "typeorm";
import StavkaUgovora from "../entity/stavkaUgovora";
import Ugovor from "../entity/ugovor";

export const res = {
  async kreirajUgovor(parent, args, context, info) {
    return await getManager().transaction(async (manager) => {
      const ugovorDTO = args.ug;
      const stavke = ugovorDTO.stavke;
      //   console.log(ugovorDTO);
      ugovorDTO.id = undefined;
      const ugovor = await manager.save(Ugovor, ugovorDTO);
      //   ugovor.stavke = [];
      /*  console.log('pre for petlje');
             console.log(stavke.length);
             for (let stavkaDTO of stavke) {
                 console.log('for petlja')
                 const stavka = await manager.save(StavkaUgovora, { opis: stavkaDTO.opis, ugovor: ugovor.id }) as StavkaUgovora;
                 console.log(stavka.id);
 
             } */
      return ugovor;
    });
  },
  async izmeniUgovor(parent, args, context, info) {
    const id = await getManager().transaction(async (manager) => {
      const ugovorDTO = args.ug;
      const id = args.id;
      //  console.log(args);
      //   console.log(id);
      const stavke = ugovorDTO.stavke;
      let ugovor = await manager.find(Ugovor, {
        where: {
          id: id,
        },
      })[0];
      console.log(ugovor);
      ugovor = await manager.save(Ugovor, {
        ...ugovor,
        ...ugovorDTO,
        id: id,
        stavke: [],
      });

      for (let stavka of stavke) {
        if (stavka.obrisana) {
          await manager.delete(StavkaUgovora, {
            id: stavka.id,
            ugovor: {
              id: ugovor.id,
            },
          } as FindConditions<StavkaUgovora>);
        } else {
          const st = await manager.findOne(StavkaUgovora, {
            where: {
              id: stavka.id,
              ugovor: {
                id: ugovor.id,
              },
            },
          });
          if (st) {
            const izmenjenaStavka = await manager.save(StavkaUgovora, {
              ...st,
              ...stavka,
            });
            ugovor.stavke.push(izmenjenaStavka);
          } else {
            const novaStavka = (await manager.save(StavkaUgovora, {
              opis: stavka.opis,
              ugovor: (ugovor as any).id,
            })) as StavkaUgovora;

            ugovor.stavke.push(novaStavka);
          }
        }
      }

      return ugovor.id;
    });
    return getRepository(Ugovor).findOne(id);
  },
  async obrisiUgovor(parent, args, context, info) {
    const id = args.id;
    getRepository(Ugovor).delete(id);
    return "success";
  },
};

export default res;
