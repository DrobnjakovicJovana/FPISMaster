import {
  Column,
  PrimaryGeneratedColumn,
  Entity,
  OneToMany,
  ManyToOne,
} from "typeorm";
import Proizvod from "./proizvod";
import Adresa from "./adresa";
@Entity()
class Proizvodjac {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  naziv: string;

  @OneToMany((type) => Proizvod, (p) => p.proiz, {
    eager: false,
  })
  proizvodi: Proizvod[];
  @ManyToOne((alias) => Adresa, (p) => p.proizvodjaci, {
    eager: true,
  })
  adresa: Adresa;

  constructor(
    id: number,
    naziv: string,
    adresa: Adresa,
    proizvodi: Proizvod[]
  ) {
    this.id = id;
    this.naziv = naziv;
    this.adresa = adresa;
    this.proizvodi = proizvodi;
  }
}
export default Proizvodjac;
