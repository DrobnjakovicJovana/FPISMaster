import {
  Column,
  PrimaryGeneratedColumn,
  Entity,
  ManyToOne,
  OneToMany,
} from "typeorm";
import Klijent from "./klijent";
import Proizvod from "./proizvod";
import StavkaUgovora from "./stavkaUgovora";
import Adresa from "./adresa";

@Entity()
class Ugovor {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne((type) => Klijent, {
    eager: true,
  })
  klijent: Klijent;

  @ManyToOne((type) => Adresa, {
    eager: true,
  })
  adresa: Adresa;

  @ManyToOne((type) => Proizvod, {
    eager: true,
  })
  proizvod: Proizvod;

  @Column()
  faza: boolean;

  @OneToMany((type) => StavkaUgovora, (p) => p.ugovor, {
    eager: true,
    cascade: true
  })
  stavke: StavkaUgovora[];

  @Column()
  datum: Date;
  constructor(
    id: number,
    adresa: Adresa,
    klijent: Klijent,
    proizvod: Proizvod,
    faza: boolean,
    datum: Date,
    stavke: StavkaUgovora[]
  ) {
    this.id = id;
    this.klijent = klijent;
    this.proizvod = proizvod;
    this.adresa = adresa;
    this.faza = faza;
    this.datum = datum;
    this.stavke = stavke;
  }
}

export default Ugovor;
