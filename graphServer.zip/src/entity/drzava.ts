import { Column, PrimaryGeneratedColumn, Entity, OneToMany } from "typeorm";

@Entity()
class Drzava {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  naziv: string;


  constructor(id: number, naziv: string) {
    this.id = id;
    this.naziv = naziv;
  }
}

export default Drzava;
