import {
  Column,
  PrimaryGeneratedColumn,
  Entity,
  ManyToOne,
} from "typeorm";
import Drzava from "./drzava";

@Entity()
class Mesto {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  naziv: string;

  @ManyToOne((type) => Drzava, { eager: true })
  drzava: Drzava;


  constructor(id: number, naziv: string, drzava: Drzava) {
    this.id = id;
    this.naziv = naziv;
    this.drzava = drzava;

  }
}

export default Mesto;
