import { Column, PrimaryGeneratedColumn, Entity, ManyToOne } from "typeorm";
import Proizvodjac from "./proizvodjac";


@Entity()
class Proizvod {
  @PrimaryGeneratedColumn()
  private id: number;

  @Column()
  private naziv: string;

  @Column()
  private pdv: number;
  @ManyToOne((type) => Proizvodjac, (p) => p.proizvodi, {
    eager: true,
  })
  proiz: Proizvodjac;


  constructor(id: number, naziv: string, pdv: number) {
    this.id = id;
    this.naziv = naziv;
    this.pdv = pdv;

  }
}

export default Proizvod;
