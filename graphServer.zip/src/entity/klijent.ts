import {
  Column,
  PrimaryGeneratedColumn,
  Entity,
  ManyToOne,
} from "typeorm";
import Adresa from "./adresa";

@Entity()
class Klijent {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  naziv: string;

  @ManyToOne((type) => Adresa, (p) => p.klijenti, {
    eager: true,
  })
  adresa: Adresa;



  constructor(id: number, naziv: string, adresa: Adresa) {
    this.id = id;
    this.naziv = naziv;
    this.adresa = adresa;

  }
}

export default Klijent;
