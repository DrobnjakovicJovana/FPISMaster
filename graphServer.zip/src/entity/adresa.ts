import {
  Column,
  PrimaryGeneratedColumn,
  Entity,
  ManyToOne,
  OneToMany,
} from "typeorm";
import Mesto from "./mesto";
import Klijent from "./klijent";
import Proizvodjac from "./proizvodjac";

@Entity()
class Adresa {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  naziv: string;

  @Column()
  broj: string;

  @ManyToOne((type) => Mesto, { eager: true, primary: true })
  mesto: Mesto;

  @OneToMany((type) => Klijent, (k) => k.adresa, {
    eager: false,
  })
  klijenti: Klijent[];
  @OneToMany((type) => Proizvodjac, (p) => p.adresa, {
    eager: false,
  })
  proizvodjaci: Proizvodjac[];
  constructor(
    id: number,
    naziv: string,
    klijenti: Klijent[],
    broj: string,
    mesto: Mesto
  ) {
    this.id = id;

    this.klijenti = klijenti;
    this.broj = broj;
    this.naziv = naziv;
    this.mesto = mesto;
  }
}

export default Adresa;
