import { gql } from 'apollo-server';

export const tipovi = gql`

    type Drzava{
        id:Int,
        naziv:String
    }
    type Mesto{
        id:Int,
        naziv:String
        drzava:Drzava
    }
    type Adresa{
        id:Int,
        naziv:String,
        broj:Int,
        mesto:Mesto
    },
    type Klijent{
        id:Int,
        naziv:String,
        adresa:Adresa
    }
    type Proizvod{
        id:Int,
        naziv:String,
        pdv:Int,
        proiz:Proizvodjac
    },
    type Ugovor{
        id:Int,
        klijent:Klijent,
        adresa:Adresa,
        faza:Boolean,
        proizvod:Proizvod,
        datum:String,
        stavke:[StavkaUgovora]
    }
    type StavkaUgovora{
        id:Int,
        opis:String,
        ugovor:Ugovor,
        obrisana: Boolean
    }
    type Proizvodjac{
        id:Int,
        naziv:String,
        adresa:Adresa
    }
    
    input AdresaInput{
        id:Int,
        mesto:Int,
    }
    input StavkaInput {
        id:Int,
        opis:String,
        obrisana: Boolean
       
    }
    input UgovorInput {
        id:Int,
        klijent:Int,
        adresa:Int,
        faza:Boolean,
        proizvod:Int,
        datum:String,
        stavke:[StavkaInput]
    }
    
    type Query{
        adrese:[Adresa],
        drzave:[Drzava],
        klijenti:[Klijent],
        mesta:[Mesto],
        
        proizvodi:[Proizvod],
        ugovori:[Ugovor],
        ugovor(id:Int):Ugovor
    }
    type Mutation{
        kreirajUgovor(ug:UgovorInput):Ugovor,
        izmeniUgovor(ug:UgovorInput,id:Int):Ugovor,
        obrisiUgovor(id:Int):String
    }
   

`

export default tipovi;
