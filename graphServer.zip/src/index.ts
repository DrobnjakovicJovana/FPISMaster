import "reflect-metadata";
import { createConnection } from "typeorm";
import { ApolloServer, ForbiddenError, UserInputError } from 'apollo-server'
import tipovi from './typedefs'
import queries from './resolvers/queryResolver';
import mutations from './resolvers/mutationResolver'
import * as jwt from 'jsonwebtoken';
createConnection().then(async connection => {


    const server = new ApolloServer({
        typeDefs: tipovi,
        context: ({ req }) => {
            const header = req.headers['authorization'] as string | undefined;
            if (!header) {
                throw new UserInputError("token nije poslat ");
            }
            const splitted = header.split(' ');
            if (splitted.length !== 2) {
                throw new UserInputError("token je u losem formatu");
            };
            const token = splitted[1];

            jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
                console.log(err);
                if (err) {
                    throw new ForbiddenError('Invalid token');
                }
                req.user = user;
            })

        },
        resolvers: {
            Query: queries,
            Mutation: mutations
        },

    })

    server.listen({
        port: 6001
    }).then(val => {
        console.log(`server is listening on ${val.url}`)
    })

}).catch(error => console.log(error));
