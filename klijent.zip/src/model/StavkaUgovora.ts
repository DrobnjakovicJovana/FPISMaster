import { Ugovor } from "./ugovor";

export interface StavkaUgovora {
  ugovor: Ugovor | undefined;
  id: number | undefined;
  opis: string;
  obrisana: boolean;
  promenjena: boolean;
}
