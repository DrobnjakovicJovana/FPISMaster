import { Proizvodjac } from "./Proizvodjac";

export class Proizvod {
  id?: number;
  naziv: string;
  //proizvodjac: string;
  pdv: number;
  proiz?: Proizvodjac;
  constructor(
    id: number,
    naziv: string,
    //proizvodjac: string,
    pdv: number,
    proiz: Proizvodjac
  ) {
    this.id = id;
    this.naziv = naziv;
    // this.proizvodjac = proizvodjac;
    this.pdv = pdv;
    this.proiz = proiz;
  }
}
