
export class Proizvodjac {
  id: number;
  naziv: string;
  constructor(id: number, naziv: string) {
    this.id = id;
    this.naziv = naziv;
  }
}
