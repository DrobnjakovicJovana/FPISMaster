import { Adresa } from "./Adresa";
import { Proizvod } from "./Proizvod";
import { StavkaUgovora } from "./StavkaUgovora";
import { Klijent } from "./Klijent";

export interface Ugovor {
    id: number | null,
    adresa: Adresa | null,
    proizvod: Proizvod | null,
    faza: boolean | null,
    datum: Date | null,
    stavke: StavkaUgovora[],
    klijent: Klijent | null

}