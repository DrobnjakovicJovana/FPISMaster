export interface User {
    id: number,
    ime: string,
    prezime: string,
    username: string,
    password?: string
}