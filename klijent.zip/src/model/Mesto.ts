import { Drzava } from "./Drzava";

export class Mesto {
  id: number;
  naziv: string;

  drzava: Drzava;

  constructor(
    id: number,
    naziv: string,

    drzava: Drzava
  ) {
    this.id = id;
    this.naziv = naziv;

    this.drzava = drzava;
  }
}
