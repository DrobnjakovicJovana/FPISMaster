import { Mesto } from "./Mesto";

export class Adresa {
  id: number;
  naziv: string;
  mesto: Mesto;
  broj: number;
  constructor(id: number, naziv: string, mesto: Mesto, broj: number) {
    this.id = id;
    this.naziv = naziv;
    this.mesto = mesto;
    this.broj = broj;
  }
}
