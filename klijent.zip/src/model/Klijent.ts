export interface Klijent {

    id: number,
    naziv: string
}