import axios from "axios";
import React, { useState } from "react";
import { Grid, Form } from "semantic-ui-react";
import "../App.css";
import "../proizvodPage.css";
import { Proizvod } from "../model/Proizvod";
import { Proizvodjac } from "../model/Proizvodjac";
import ModalNoviProizvod from "./ModalniNoviProizvod";
import TabelaProizvod from "./TabelaProizvod";
import FormaProizvod from "./FormaProizvod";
import FormaZaFiltriranjeProizvoda from "./FormaZaFiltriranjeProizvoda";

export default function ProizvodStrana() {
  const [proizvodi, setProizvodi] = React.useState<Proizvod[]>([]);
  const [proizvodi1, setProizvodi1] = React.useState<Proizvod[]>([]);
  const [proizvodjac, setProizvodjac] = React.useState<Proizvodjac | undefined>(
    undefined
  );
  const [proizvodjaci, setProizvodjaci] = React.useState<Proizvodjac[]>([]);
  const [Pretrazi, setPretraziUFormi] = useState("");
  const [trenutniProizvod, setTrenutniProizvod] = React.useState<
    Proizvod | undefined
  >(undefined);

  const promeniProizvodjaca = (id: number) => {
    let kl = proizvodjaci.find((value) => value.id === id);
    setProizvodjac(kl);
  };
  const promeniProizvod = (p: Proizvod) => {
    if (p === trenutniProizvod) {
      setTrenutniProizvod(undefined);
    } else {
      setTrenutniProizvod(p);
    }
  };
  const izmeniProizvod = () => (
    id: number,
    naziv: String,
    pdv: number,
    proiz: Proizvodjac
  ) => {
    axios
      .patch("http://localhost:5000/proizvod/" + id, {
        naziv: naziv,
        pdv: pdv,
        proiz: proiz,
      } as Proizvod)
      .then((value) => {
        alert("Uspesno izmenjen proizvod");
        console.log({ poruka: value.data });
        let ug = value.data as Proizvod;
        let ugovori1 = [...proizvodi];
        let ind = ugovori1.findIndex((element) => element.id === ug.id);
        ugovori1[ind] = { ...ug };
        setProizvodi([...ugovori1]);
        setTrenutniProizvod(undefined);
      });
  };
  React.useEffect(() => {
    axios.get("http://localhost:5000/proizvod").then((value) => {
      let u = (value.data as Proizvod[]).map(
        (proizvod): Proizvod => {
          return {
            ...proizvod,
            naziv: proizvod.naziv,
            pdv: proizvod.pdv,
            proiz: new Proizvodjac(proizvod!.proiz!.id, proizvod.proiz!.naziv),
          };
        }
      );
      setProizvodi(u);
      setProizvodi1(u);
    });
  }, []);
  return (
    <Grid columns="15">
      <Grid.Row>
        <Form.Input
          placeholder="pretrazi po nazivu"
          value={Pretrazi}
          onChange={(event, data) => {
            console.log(data);
            setPretraziUFormi(data.value);
          }}
        />
        <button
          onClick={(e) => {
            e.preventDefault();
            console.log(Pretrazi);
            axios.get("http://localhost:5000/proizvod").then((value) => {
              const data = value.data as Proizvod[];

              let p1 = data.filter((p) =>
                new RegExp(`^${Pretrazi.toUpperCase()}`).test(
                  p.naziv.toUpperCase()
                )
              );
              setProizvodi(p1);
              setTrenutniProizvod(undefined);
            });
          }}
        >
          Pretrazi
        </button>
      </Grid.Row>

      <ModalNoviProizvod
        dodajProizvod={(ug) => {
          setProizvodi([...proizvodi1, ug]);
          //  setTrenutniProizvod(ug);
          setPretraziUFormi("");
        }}
      />
      <Grid.Row columns="10">
        <Grid.Column width={"10"}>
          <TabelaProizvod
            proizvodi={proizvodi}
            izabraniProizvod={trenutniProizvod}
            promeniProizvod={promeniProizvod}
          />
        </Grid.Column>
      </Grid.Row>
      <Grid.Row>
        <Grid.Column width="8">
          {trenutniProizvod && (
            <FormaProizvod
              proizvod={trenutniProizvod}
              onIzmeni={izmeniProizvod()}
              onObrisi={() => {
                axios
                  .delete(
                    "http://localhost:5000/proizvod/" + trenutniProizvod?.id
                  )
                  .then((value) => {
                    alert("Uspesno obrisan proizvod");
                    setProizvodi(
                      proizvodi.filter(
                        (element) => element.id !== trenutniProizvod?.id
                      )
                    );
                    setTrenutniProizvod(undefined);
                  });
              }}
            />
          )}
        </Grid.Column>
      </Grid.Row>
    </Grid>
  );
}
