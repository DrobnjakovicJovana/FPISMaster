import React from 'react';
import { Dropdown, Form, DropdownItemProps } from 'semantic-ui-react';
import { Klijent } from '../model/Klijent';

interface Props {
    klijenti: Klijent[],
    promeniKlijenta: (id: number) => void;
}
export default function FormaZaFiltriranje(props: Props) {
    return (
        <Form>
            <Dropdown
                selection
                placeholder='izaberi klijenta'
                onChange={(event, data) => {
                    console.log(data);
                    props.promeniKlijenta(data.value as number);
                }}
                options={props.klijenti.map((value): DropdownItemProps => {
                    return {

                        text: value.naziv,

                        value: value.id,
                        key: value.id

                    }
                })}
            />
        </Form>
    );
}
