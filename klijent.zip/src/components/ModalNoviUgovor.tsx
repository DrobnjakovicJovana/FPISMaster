import React from "react";

import { Modal, Button, Grid } from "semantic-ui-react";
import FormaUgovor from "./FormaUgovor";
import FormaStavka from "./FormaStavka";
import TabelaStavke from "./TabelaStavke";
import { Klijent } from "../model/Klijent";
import { Proizvod } from "../model/Proizvod";
import { Adresa } from "../model/Adresa";
import { Drzava } from "../model/Drzava";
import { Mesto } from "../model/Mesto";
import { StavkaUgovora } from "../model/StavkaUgovora";
import { Ugovor } from "../model/ugovor";
import { gql, useMutation } from "@apollo/client";
import Cookie from "js-cookie";
import { refresh } from "../util";
interface Props {
  dodajUgovor: (u: Ugovor) => void;
}

const KREIRAJ_UGOVOR = gql`
  mutation kreiraj($ugovor: UgovorInput) {
    kreirajUgovor(ug: $ugovor) {
      id
      stavke {
        id
      }
    }
  }
`;

export default function ModalNoviUgovor(props: Props) {
  const [klijent, setKlijent] = React.useState<Klijent | undefined>(undefined);
  const [klijenti, setKlijenti] = React.useState<Klijent[]>([]);
  const [proizvod, setProizvod] = React.useState<Proizvod | undefined>(
    undefined
  );
  const [kreiraj, { error }] = useMutation(KREIRAJ_UGOVOR);
  const [idUgovor, setIdUgovor] = React.useState<number | null>(null);
  const [faza, setFaza] = React.useState<boolean>(false);
  const [datum, setDatum] = React.useState<Date | undefined>(undefined);
  const [adresa, setAdresa] = React.useState<Adresa | undefined>(undefined);
  const [stavke, setStavke] = React.useState<StavkaUgovora[]>([]);
  const [stavke1, setStavke1] = React.useState<StavkaUgovora[]>([]);
  const [trenutnaStavka, setTrenutnaStavka] = React.useState<
    number | undefined
  >(undefined);

  return (
    <Modal trigger={<Button>Novi ugovor</Button>}>
      <Grid columns="16">
        <Grid.Row>
          <Grid.Column width="4">
            <FormaUgovor
              potpisan={faza}
              setPotpisan={setFaza}
              setKlijent={setKlijent}
              setAdresa={setAdresa}
              setProizvod={setProizvod}
              setDatum={setDatum}
            />
          </Grid.Column>
          <Grid.Column width="11">
            <TabelaStavke
              setTrenutnaStavka={setTrenutnaStavka}
              stavke={stavke.filter((element) => !element.obrisana)}
              trenutnaStavka={trenutnaStavka}
            />
            <FormaStavka
              onDodaj={(opis) => {
                setStavke([...stavke, { opis: opis } as StavkaUgovora]);
              }}
              stavka={
                trenutnaStavka !== undefined
                  ? stavke[trenutnaStavka]
                  : undefined
              }
              onIzmeni={(st) => {
                setStavke(
                  stavke.map((element, index) => {
                    if (index === trenutnaStavka) {
                      return st;
                    } else {
                      return element;
                    }
                  })
                );
              }}
              onObrisi={() => {
                setStavke(
                  stavke.map((element, index) => {
                    return { ...element, obrisana: true };
                  })
                );
              }}
            />
          </Grid.Column>
        </Grid.Row>
        <Grid.Row>
          <Grid.Column floated="right" width="15">
            <Button
              onClick={async (e) => {
                e.preventDefault();

                const noviUgovor = {
                  adresa: adresa?.id || null,
                  datum: datum || new Date(),
                  faza: faza,
                  id: null,
                  klijent: klijent?.id || null,
                  proizvod: proizvod?.id || null,
                  stavke: stavke,
                };
                console.log("kliknuto");
                if (
                  adresa == undefined ||
                  proizvod == undefined ||
                  klijent == undefined
                ) {
                  alert("Popunite sva polja!");
                  return;
                }
                const result = await refresh((context: any) => {
                  return kreiraj({
                    context: context,
                    variables: {
                      ugovor: noviUgovor,
                    },
                  });
                });
                alert("Uspesno kreiran ugovor");
                const ugovor = result.data.kreirajUgovor;

                props.dodajUgovor({
                  ...noviUgovor,
                  id: ugovor.id,
                  klijent: klijent,
                  proizvod: proizvod,
                  adresa: adresa,
                  stavke: noviUgovor.stavke.map((element, index) => {
                    return { ...element, id: ugovor.stavke[index].id };
                  }),
                });

                /*  Axios.post("http://localhost:5000/ugovor", noviUgovor)
                   .then((value) => {
                     console.log((value.data as Ugovor).id);
 
                     stavke.map((element, index) => {
                       element.ugovor = value.data as Ugovor;
                     });
 
                     Axios.post("http://localhost:5000/stavka", stavke).then(
                       (value) => {
                         setStavke1(value.data as StavkaUgovora[]);
                         stavke[0].id = (value.data as StavkaUgovora)[0].id;
                         var d = stavke[0].id;
                         for (var i = 1; i < stavke.length; i++) {
                           var d = stavke[i - 1].id;
                           if (d !== undefined) stavke[i].id = d + 1;
                         }
                         setStavke(stavke);
                       }
                     );
                     let noviUgovor: Ugovor = {
                       ...(value.data as Ugovor),
                       datum: new Date(value.data.datum),
                       stavke: stavke,
                     };
                     //  console.log(value.data.stavke as StavkaUgovora[]);
                     // setStavke(value.data as StavkaUgovora[]);
                     //    noviUgovor.stavke = stavke;
                     console.log(stavke);
                     props.dodajUgovor(noviUgovor);
                     alert("Uspesno ste dodali ugovor!");
                   })
                   .catch((err) => console.log(err)); */
              }}
              //STAVKE U NOVOM UGOVORU NEMAJU ID, TREBA DA OPET UVITAM STAVKE I SETUJEM IH
            >
              Sacuvaj ugovor
            </Button>
          </Grid.Column>
        </Grid.Row>
      </Grid>
    </Modal>
  );
}
