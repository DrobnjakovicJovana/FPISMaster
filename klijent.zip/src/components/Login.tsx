import React, { useState } from "react";
import { Form, Grid } from "semantic-ui-react";
import axios from "axios";
import Cookie from "js-cookie";
import { User } from "../model/User";

interface Props {
  setUser: (user: User) => void;
}

export default function Login(props: Props) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  return (
    <Grid padded centered>
      <Grid.Column width="9" style={{ backgroundColor: "white" }}>
        <Form
          onSubmit={async () => {
            try {
              const result = await axios.post("http://localhost:4000/login", {
                username: username,
                password: password,
              });
              props.setUser(result.data.user);
              Cookie.set("REFRESH_TOKEN", result.data.refresh_token);
              Cookie.set("ACCESS_TOKEN", result.data.access_token);
              axios.defaults.headers["authorization"] =
                "Bearer " + result.data.access_token;
            } catch (error) {}
          }}
        >
          <Form.Input
            label="Username"
            value={username}
            onChange={(e) => {
              const value = e.currentTarget.value;
              setUsername(value);
            }}
          />
          <Form.Input
            type="password"
            label="Sifra"
            value={password}
            onChange={(e) => {
              const value = e.currentTarget.value;
              setPassword(value);
            }}
          />
          <Form.Button fluid>Login</Form.Button>
        </Form>
      </Grid.Column>
    </Grid>
  );
}
