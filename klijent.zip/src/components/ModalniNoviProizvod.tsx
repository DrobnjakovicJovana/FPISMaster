import React, { useState } from "react";
import axios from "axios";

import { Modal, Button, Grid } from "semantic-ui-react";

import { Proizvod } from "../model/Proizvod";

import Axios from "axios";
import { Proizvodjac } from "../model/Proizvodjac";
import FormaProizvod from "./FormaProizvod";
interface Props {
  dodajProizvod: (p: Proizvod) => void;
}

export default function ModalNoviUgovor(props: Props) {
  const [proizvodjac, setProizvodjac] = React.useState<Proizvodjac | undefined>(
    undefined
  );
  const [pdv, setPdv] = React.useState<number>(0);
  const [naziv, setNaziv] = useState("");

  return (
    <Modal trigger={<Button>Novi proizvod</Button>}>
      <FormaProizvod
        setProizvodjac={setProizvodjac}
        setNaziv={setNaziv}
        setPDV={setPdv}
      />

      <Button
        onClick={(e) => {
          e.preventDefault();

          const noviProizvod: Proizvod = {
            naziv: naziv || "",
            pdv: pdv || 0,
            proiz: proizvodjac || undefined,
          };
          console.log("kliknuto");
          if (proizvodjac === undefined || naziv == "") {
            alert("Popunite sva polja!");
            return;
          }
          Axios.post("http://localhost:5000/proizvod", noviProizvod)
            .then((value) => {
              console.log((value.data as Proizvod).id);

              console.log("then");
              console.log(value.data);
              let noviProizvod: Proizvod = {
                ...(value.data as Proizvod),
              };
              props.dodajProizvod(noviProizvod);
              alert("Uspesno sacuvan proizvod");
            })
            .catch((err) => console.log(err));
        }}
      >
        Sacuvaj proizvod
      </Button>
    </Modal>
  );
}
