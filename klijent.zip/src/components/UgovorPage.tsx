import axios from "axios";
import React, { useEffect } from "react";
import { Grid, Dropdown, DropdownItemProps } from "semantic-ui-react";
import { Adresa } from "../model/Adresa";
import { Drzava } from "../model/Drzava";
import { Klijent } from "../model/Klijent";
import { Mesto } from "../model/Mesto";
import { Proizvod } from "../model/Proizvod";
import { Proizvodjac } from "../model/Proizvodjac";
import { Ugovor } from "../model/ugovor";
import ModalNoviUgovor from "./ModalNoviUgovor";
import FormaStavka from "./FormaStavka";
import FormaUgovor from "./FormaUgovor";
import TabelaStavke from "./TabelaStavke";
import TabelaUgovora from "./TabelaUgovor";
import { StavkaUgovora } from "../model/StavkaUgovora";
import { gql, useLazyQuery, useMutation } from "@apollo/client";
import Cookie from "js-cookie";
import { refresh } from "../util";

const FETCH_UGOVOR = gql`
  query vratiUgovore {
    ugovori {
      id
      klijent {
        id
        naziv
      }
      adresa {
        id
        naziv
        broj
        mesto {
          id
          naziv
          drzava {
            id
            naziv
          }
        }
      }
      proizvod {
        id
        naziv
        pdv
        proiz {
          id
          naziv
        }
      }
      datum
      stavke {
        id
        opis
      }
    }
  }
`;
const DELETE_UGOVOR = gql`
  mutation obrisiUgovor($idUgovora: Int) {
    obrisiUgovor(id: $idUgovora)
  }
`;
const IZMENI_UGOVOR = gql`
  mutation izmeni($ugovor: UgovorInput, $idUgovora: Int) {
    izmeniUgovor(ug: $ugovor, id: $idUgovora) {
      id
      stavke {
        id
      }
    }
  }
`;

let idGen = -1;

export default function UgovorStrana() {
  const [ugovori, setUgovori] = React.useState<Ugovor[]>([]);
  const [klijent, setKlijent] = React.useState<Klijent | undefined>(undefined);
  const [getUgovori, { error, data }] = useLazyQuery(FETCH_UGOVOR);
  const [klijenti, setKlijenti] = React.useState<Klijent[]>([]);
  const [stavke, setStavke] = React.useState<StavkaUgovora[]>([]);
  const [obrisi, { error: obrisiError }] = useMutation(DELETE_UGOVOR);
  const [izmeni, { error: izmeniError }] = useMutation(IZMENI_UGOVOR);
  const [trenutnaStavka, setTrenutnaStavka] = React.useState<
    number | undefined
  >(undefined);
  const [potpisan, setPotpisan] = React.useState(false);
  const [trenutniUgovor, setTrenutniUgovor] = React.useState<
    Ugovor | undefined
  >(undefined);
  const [stavkaID, setStavkaID] = React.useState<number | undefined>(undefined);
  const promeniKlijenta = (id: number) => {
    let kl = klijenti.find((value) => value.id === id);
    setKlijent(kl);
  };
  useEffect(() => {
    if (!error) {
      return;
    }
    refresh((context) => {
      getUgovori({ context: context });
    });
  }, [error]);
  const promeniUgovor = (u: Ugovor) => {
    if (u === trenutniUgovor) {
      setTrenutniUgovor(undefined);
    } else {
      setTrenutniUgovor(u);
      setStavke(u.stavke);
      console.log(stavke);
    }
  };

  const izmeniUgovor = (stavke: StavkaUgovora[]) => (
    id: number,
    klijent: Klijent,
    proizvod: Proizvod,
    faza: boolean,
    datum: Date,
    adresa: Adresa
  ) => {
    refresh(async (context: any) => {
      return izmeni({
        variables: {
          idUgovora: id,
          ugovor: {
            klijent: klijent.id,
            proizvod: proizvod.id,
            faza: faza,
            datum: datum.toISOString(),
            adresa: adresa.id,
            stavke: stavke.map((element) => {
              return {
                id: element.id,
                obrisana: element.obrisana,
                opis: element.opis,
              };
            }),
          },
        },
        context: context,
      });
    }).then((result) => {
      alert("Uspesno izmenjen ugovor");
      setTrenutniUgovor(undefined);
      let ug = result.data.izmeniUgovor as Ugovor;
      let ugovori1 = [...ugovori];

      setUgovori((prev) => {
        return prev.map((element) => {
          if (element.id !== id) {
            return element;
          }
          return {
            id: id,
            klijent: klijent,
            proizvod: proizvod,
            adresa: adresa,
            faza: faza,
            datum: datum,
            stavke: stavke!,
          };
        });
      });
    });

    /* axios
      .patch("http://localhost:5000/ugovor/" + id, {
        klijent: klijent,
        adresa: adresa,
        datum: datum,
        faza: faza,
        proizvod: proizvod,
        stavke: noveStavke,
      } as Ugovor)
      .then((value) => {
        alert("Uspesno ste izmenili ugovor!");
        console.log({ poruka: value.data });
        let ug = value.data as Ugovor;
        let ugovori1 = [...ugovori];
        let ind = ugovori1.findIndex((element) => element.id === ug.id);
        ugovori1[ind] = { ...ug, datum: new Date(ug.datum!) };
        setUgovori([...ugovori1]);
        setTrenutniUgovor(undefined);
      }); */
  };
  useEffect(() => {
    refresh(async (context: any) => {
      return getUgovori({
        context: context,
      });
    });
  }, []);

  React.useEffect(() => {
    if (!data || !data.ugovori) {
      return;
    }
    let u = (data.ugovori as Ugovor[]).map(
      (ugovor): Ugovor => {
        return {
          ...ugovor,
          klijent: {
            id: ugovor.klijent?.id || -1,
            naziv: ugovor.klijent?.naziv || "",
          },
          adresa: new Adresa(
            ugovor.adresa!.id,
            ugovor.adresa!.naziv,
            new Mesto(
              ugovor.adresa!.mesto.id,
              ugovor.adresa!.mesto.naziv,
              new Drzava(
                ugovor.adresa!.mesto.drzava.id,
                ugovor.adresa!.mesto.drzava.naziv
              )
            ),
            ugovor.adresa!.broj
          ),
          proizvod: new Proizvod(
            ugovor.proizvod!.id!,
            ugovor.proizvod!.naziv,
            ugovor.proizvod!.pdv,
            new Proizvodjac(
              ugovor.proizvod!.proiz!.id!,
              ugovor.proizvod!.proiz!.naziv!
            )
          ),
          datum: new Date(ugovor.datum!),
        };
      }
    );
    setUgovori(u);
    let klijenti: Klijent[] = u.map((ugovor1) => {
      return ugovor1.klijent!;
    });
    let klijenti1: Klijent[] = [];

    for (let k1 of klijenti) {
      let pom = klijenti1.find((pomKlijent) => pomKlijent.id === k1.id);
      if (!pom) {
        klijenti1.push(k1);
      }
    }
    setKlijenti(klijenti1);
  }, [data]);
  return (
    <Grid columns="15">
      <Grid.Row>
        <Dropdown
          selection
          placeholder="Pretrazi po klijentu"
          value={klijent && klijent.id}
          onChange={(event, data) => {
            console.log(data);
            promeniKlijenta(data.value as number);
            setTrenutniUgovor(undefined);
          }}
          options={klijenti.map(
            (value): DropdownItemProps => {
              return {
                text: value.naziv,

                value: value.id,
                key: value.id,
              };
            }
          )}
        />

        <ModalNoviUgovor
          dodajUgovor={(ug) => {
            setUgovori([...ugovori, ug]);
            if (klijent !== undefined) {
              setKlijent(ug.klijent!);
              promeniKlijenta(ug.klijent!.id);
            }
            // setTrenutniUgovor(ug);
            // setStavke(ug.stavke);
          }}
        />
      </Grid.Row>
      <Grid.Row columns="15">
        <Grid.Column width={trenutniUgovor ? "8" : "14"}>
          <TabelaUgovora
            ugovori={ugovori.filter(
              (value) => !klijent || value.klijent!.id === klijent.id
            )}
            izabraniUgovor={trenutniUgovor}
            promeniUgovor={promeniUgovor}
          />
        </Grid.Column>
        {trenutniUgovor && (
          <Grid.Column width="6">
            <TabelaStavke
              setStavkaID={setStavkaID}
              stavkaID={stavkaID}
              stavke={stavke.filter((element) => !element.obrisana)}
              setTrenutnaStavka={setTrenutnaStavka}
              trenutnaStavka={trenutnaStavka}
            />
            <FormaStavka
              id={stavkaID}
              onDodaj={(opis) => {
                console.log(opis);
                let st: StavkaUgovora = {
                  opis: opis,
                  ugovor: trenutniUgovor,
                  id: idGen--,
                  obrisana: false,
                  promenjena: true,
                };
                setStavke([...stavke, st]);
              }}
              stavka={
                trenutnaStavka !== undefined
                  ? stavke.find((element) => element.id === stavkaID)
                  : undefined
              }
              onIzmeni={(st) => {
                setStavke((prev) =>
                  prev.map((element, index) => {
                    if (element.id === stavkaID) {
                      return st;
                    } else {
                      return element;
                    }
                  })
                );
              }}
              onObrisi={() => {
                setStavke((prev) => {
                  return prev.map((element) => {
                    if (element.id === stavkaID) {
                      return {
                        ...element,
                        obrisana: true,
                      };
                    }
                    return element;
                  });
                });
              }}
            />
          </Grid.Column>
        )}
      </Grid.Row>
      <Grid.Row>
        <Grid.Column width="8">
          {trenutniUgovor && (
            <FormaUgovor
              ugovor={trenutniUgovor}
              potpisan={potpisan}
              setPotpisan={setPotpisan}
              onIzmeni={izmeniUgovor(stavke)}
              onObrisi={() => {
                /*  axios
                   .delete("http://localhost:5000/ugovor/" + trenutniUgovor.id)
                   .then((value) => {
                     alert("Uspesno ste obrisali ugovor!");
                     setUgovori(
                       ugovori.filter(
                         (element) => element.id !== trenutniUgovor.id
                       )
                     );
                     setTrenutniUgovor(undefined);
                     setStavke([]);
                   }); */
                refresh(() => {
                  return obrisi({
                    variables: {
                      idUgovora: trenutniUgovor.id,
                    },
                    context: {
                      headers: {
                        authorization: "Bearer " + Cookie.get("ACCESS_TOKEN"),
                      },
                    },
                  });
                }).then((value) => {
                  alert("Uspesno obrisan ugovor");
                  setUgovori((prev) => {
                    return prev.filter(
                      (element) => element.id !== trenutniUgovor.id
                    );
                  });
                  setTrenutniUgovor(undefined);
                  setStavke([]);
                });
              }}
            />
          )}
        </Grid.Column>
      </Grid.Row>
    </Grid>
  );
}
