import React, { useState } from "react";
import { Dropdown, Form, DropdownItemProps } from "semantic-ui-react";
import { Klijent } from "../model/Klijent";
import { Proizvod } from "../model/Proizvod";
import axios from "axios";
interface Props {
  proizvodi: Proizvod[];
}
export default function FormaZaFiltriranjeProizvoda(props: Props) {
  const [Pretrazi, setPretraziUFormi] = useState("");
  return (
    <Form>
      <Form.Input
        placeholder="pretrazi po nazivu proizvoda"
        value={Pretrazi}
        onChange={(event, data) => {
          console.log(data);
          setPretraziUFormi(data.value);
        }}
      />
      <button
        onClick={(e) => {
          e.preventDefault();
          console.log(Pretrazi);
          axios.get("http://localhost:5000/proizvod").then((value) => {
            const data = value.data as Proizvod[];

            let p1 = data.filter((p) =>
              new RegExp(`^${Pretrazi}`).test(p.naziv)
            );
            props.proizvodi = p1;
          });
        }}
      >
        Pretrazi
      </button>
    </Form>
  );
}
