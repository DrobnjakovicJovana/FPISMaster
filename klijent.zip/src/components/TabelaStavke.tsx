import React from "react";
import { Table } from "semantic-ui-react";
import { StavkaUgovora } from "../model/StavkaUgovora";

interface Props {
  stavke: StavkaUgovora[];
  trenutnaStavka?: number;
  setTrenutnaStavka?: (stavka?: number) => void;
  setStavkaID?: (id: number) => void;
  stavkaID?: number;
}

export default function TabelaStavke(props: Props) {
  return (
    <Table celled inverted selectable>
      <Table.Header>
        <Table.Row>
          <Table.HeaderCell>Rb</Table.HeaderCell>
          <Table.HeaderCell>opis</Table.HeaderCell>
        </Table.Row>
      </Table.Header>
      <Table.Body>
        {props.stavke
          .filter((element) => !element.obrisana)
          .map((value, index) => {
            return (
              <Table.Row
                key={value.id}
                active={value.id === props.stavkaID}
                onClick={() => {
                  if (props.setTrenutnaStavka) {
                    props.setTrenutnaStavka(index);
                  }
                  //  console.log(value.opis);
                  //  console.log(value.id);
                  //console.log(index);
                  if (value.id && props.setStavkaID) {
                    props.setStavkaID(value.id);
                  }
                }}
              >
                <Table.Cell>{index + 1}</Table.Cell>
                <Table.Cell>{value.opis}</Table.Cell>
              </Table.Row>
            );
          })}
      </Table.Body>
    </Table>
  );
}
