import React, { useState } from 'react'
import { Form, Grid, Header } from 'semantic-ui-react'
import axios from 'axios';
import { User } from '../model/User';
import Cookie from 'js-cookie'

interface Props {
    setUser: (user: User) => void;
}

export default function Register(props: Props) {
    const [ime, setIme] = useState('');
    const [prezime, setPrezime] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [repeat, setRepeat] = useState('');
    const [passwordGreska, setPasswordGreska] = useState('');
    const [serverGreska, setserverGreska] = useState('')
    return (
        <>
            {
                serverGreska && (
                    <Header textAlign='center' as='h1' color='red'>
                        {serverGreska}
                    </Header>
                )
            }
            <Grid padded centered>

                <Grid.Column style={{ backgroundColor: 'white' }} width='9'>
                    <Form onSubmit={async () => {
                        if (password !== repeat) {
                            setPasswordGreska('Sifra nije ista u oba polja');
                            return;
                        }
                        setPasswordGreska('');
                        try {
                            const result = await axios.post('http://localhost:4000/register', {
                                ime: ime,
                                prezime: prezime,
                                username: username,
                                sifra: password
                            });
                            console.log(result.data);
                            props.setUser(result.data.user);
                            Cookie.set('REFRESH_TOKEN', result.data.refresh_token);
                            Cookie.set('ACCESS_TOKEN', result.data.access_token);
                            axios.defaults.headers['authorization'] = 'Bearer ' + result.data.access_token;
                        } catch (error) {
                            setserverGreska(error.response.statusText)
                        }
                    }}>
                        <Form.Input value={ime} onChange={(e) => {
                            const value = e.currentTarget.value;
                            setIme(value);
                        }} label='Ime' />
                        <Form.Input value={prezime} onChange={(e) => {
                            const value = e.currentTarget.value;
                            setPrezime(value);
                        }} label='Prezime' />
                        <Form.Input value={username} onChange={(e) => {
                            const value = e.currentTarget.value;
                            setUsername(value);
                        }} label='Username' />
                        <Form.Input value={password} onChange={(e) => {
                            const value = e.currentTarget.value;
                            setPassword(value);
                        }} type='password' label='Sifra' />
                        <Form.Input value={repeat} onChange={(e) => {
                            const value = e.currentTarget.value;
                            setRepeat(value);
                        }} type='password' label='Ponovite sifru' error={passwordGreska ? passwordGreska : undefined} />
                        <Form.Button fluid>Registruj se</Form.Button>
                    </Form>
                </Grid.Column>


            </Grid>
        </>
    )
}
