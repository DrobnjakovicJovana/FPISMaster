import React from "react";
import "../header.css";
import { Link } from "react-router-dom";
import { User } from "../model/User";
import { Menu } from "semantic-ui-react";
interface Props {
  user: User | undefined,
  onLogout: () => void
}
export default function Header(props: Props) {
  return (
    <Menu borderless fluid >
      {
        props.user ? (
          <>
            <Menu.Item as={Link} to='/ugovor' >Ugovor</Menu.Item>
            <Menu.Item as={Link} to='/proizvod' >Proizvod</Menu.Item>
            <Menu.Item position='right' onClick={props.onLogout} >Logout</Menu.Item>
          </>
        ) : (
          <>
            <Menu.Item as={Link} to='/' >Login</Menu.Item>
            <Menu.Item as={Link} to='/register' >Register</Menu.Item>
          </>
        )
      }



    </Menu>
  );
}
