import React from "react";
import { Table } from "semantic-ui-react";
import { Ugovor } from "../model/ugovor";
import { Proizvod } from "../model/Proizvod";

interface Props {
  proizvodi: Proizvod[];
  izabraniProizvod: Proizvod | undefined;
  promeniProizvod: (proizvod: Proizvod) => void;
}
export default function TabelaProizvod(props: Props) {
  return (
    <Table celled selectable>
      <Table.Header>
        <Table.Row>
          <Table.HeaderCell>ID</Table.HeaderCell>
          <Table.HeaderCell>Naziv</Table.HeaderCell>
          <Table.HeaderCell>Proizvodjac</Table.HeaderCell>
          <Table.HeaderCell>PDV</Table.HeaderCell>
        </Table.Row>
      </Table.Header>
      <Table.Body>
        {props.proizvodi.map((value) => {
          return (
            <Table.Row
              key={value.id!}
              active={value === props.izabraniProizvod}
              onClick={(e) => {
                props.promeniProizvod(value);
              }}
            >
              <Table.Cell>{value.id}</Table.Cell>
              <Table.Cell>{value.naziv}</Table.Cell>
              <Table.Cell>{value.proiz?.naziv}</Table.Cell>
              <Table.Cell>{value.pdv}</Table.Cell>
            </Table.Row>
          );
        })}
      </Table.Body>
    </Table>
  );
}
