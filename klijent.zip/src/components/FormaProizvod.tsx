import React, { useState } from "react";
import axios from "axios";
import {
  Button,
  Dropdown,
  Form,
  DropdownItemProps,
  Input,
} from "semantic-ui-react";

import { Proizvod } from "../model/Proizvod";
import { Proizvodjac } from "../model/Proizvodjac";

interface Props {
  proizvod?: Proizvod;

  setProizvodjac?: (proizvodjac: Proizvodjac) => void;

  setPDV?: (broj: number) => void;
  setNaziv?: (naziv: string) => void;
  onIzmeni?: (
    id: number,
    naziv: string,
    pdv: number,
    proiz: Proizvodjac
  ) => void;
  onObrisi?: () => void;
}
export default function FormaProizvod(props: Props) {
  const [proizvodjaci, setProizvodjaci] = React.useState<Proizvodjac[]>([]);
  const [selektovaniProizvodjac, setSelektovaniProizvodjac] = React.useState<
    Proizvodjac | undefined
  >(undefined);
  const [nazivUFormi, setNazivUFormi] = useState("");
  const [pdv, setPdv] = React.useState<number>(0);
  const [PDVUFormi, setPDVUFormi] = useState<number>(0);
  const [naziv, setNaziv] = useState<string>("");

  React.useEffect(() => {
    axios.get("http://localhost:5000/proizvodjac").then((value) => {
      let u = (value.data as Proizvodjac[]).map(
        (proizvodjac): Proizvodjac => {
          return {
            id: proizvodjac?.id || -1,
            naziv: proizvodjac?.naziv || "",
          };
        }
      );
      setProizvodjaci(u);
    });
  }, []);

  return (
    <Form size="large">
      {props.proizvod && <Input disabled value={props.proizvod.id} fluid />}
      <Form.Input
        type="text"
        placeholder="Unesite naziv proizvoda"
        value={naziv ? naziv : props.proizvod && props.proizvod.naziv}
        onChange={(e, data) => {
          // console.log(data.value);
          setNaziv(data.value);
          if (props.setNaziv) {
            props.setNaziv(data.value);
            console.log(data.value);
          }
        }}
      />
      <Dropdown
        placeholder="Izaberite proizvodjaca"
        search
        fluid
        selection
        value={
          (selektovaniProizvodjac && selektovaniProizvodjac.id) ||
          (props.proizvod && props.proizvod.proiz?.id)
        }
        options={proizvodjaci.map(
          (value): DropdownItemProps => {
            return {
              text: value.naziv,
              value: value.id,
              key: value.id,
            };
          }
        )}
        onChange={(e, data) => {
          let pom = proizvodjaci.find(
            (pomProizvodjac) => pomProizvodjac.id === data.value
          ) as Proizvodjac;
          setSelektovaniProizvodjac(pom);
          if (props.setProizvodjac) {
            props.setProizvodjac(pom);
          }
        }}
      />

      <Form.Input
        type="number"
        placeholder="Unesite PDV za proizvod"
        value={pdv ? pdv : props.proizvod && props.proizvod.pdv}
        onChange={(e, data) => {
          // console.log(data.value);
          setPdv(parseInt(data.value));
          if (props.setPDV) {
            props.setPDV(parseInt(data.value));
            console.log(data.value);
          }
        }}
      />
      {props.proizvod && (
        <>
          <Button
            onClick={(e) => {
              e.preventDefault();
              props.onIzmeni!(
                props.proizvod!.id!,
                naziv ? naziv : props.proizvod?.naziv!,
                pdv ? pdv : props.proizvod?.pdv!,
                selektovaniProizvodjac
                  ? selektovaniProizvodjac
                  : props.proizvod?.proiz!
              );
            }}
          >
            Izmeni
          </Button>
          <Button
            onClick={(e) => {
              e.preventDefault();
              props.onObrisi!();
            }}
          >
            {" "}
            Obrsi
          </Button>
        </>
      )}
    </Form>
  );
}
