import React from 'react';
import { Form, Button } from 'semantic-ui-react';
import { StavkaUgovora } from '../model/StavkaUgovora';

interface Props {
    id?: number,
    stavka?: StavkaUgovora;
    onDodaj?: (opis: string) => void;
    onIzmeni?: (st: StavkaUgovora) => void;
    onObrisi?: () => void;
}
export default function FormaStavka(props: Props) {
    const [opis, setOpis] = React.useState(props.stavka?.opis || '');

    React.useEffect(() => {
        setOpis(props.stavka?.opis || '');
    }, [props.stavka])
    return (

        <Form size='large'>

            <Form.TextArea
                label="Opis stavke"
                placeholder="Opis..."
                value={opis}
                onChange={(e) => {
                    setOpis(e.currentTarget.value);
                }}
            />
            <Button onClick={(e) => {
                e.preventDefault();
                if (props.onDodaj) {
                    props.onDodaj(opis);
                }
            }} >Dodaj</Button>
            <Button disabled={!props.stavka} onClick={(e) => {
                e.preventDefault();
                if (props.onIzmeni) {
                    props.onIzmeni({ id: props.id, opis: opis } as StavkaUgovora)
                }
            }}>Izmeni</Button>
            <Button disabled={!props.stavka} onClick={(e) => {
                e.preventDefault();
                if (props.onObrisi) {
                    props.onObrisi()
                }
            }}>Obrisi</Button>
        </Form>
    );
}
