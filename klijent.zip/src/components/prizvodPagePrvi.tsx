import React, { useState, useEffect } from "react";
import "../App.css";
import "../proizvodPage.css";
import { Proizvod } from "../model/Proizvod";
import axios from "axios";
import { Proizvodjac } from "../model/Proizvodjac";

export default function ProizvodStrana() {
  const [proizvodi, setProizvodi] = useState<Proizvod[]>([]);
  const [proizvodjaci, setProizvodjaci] = useState<Proizvodjac[]>([]);
  const [proizvodjac, setProizvodjac] = useState<Proizvodjac | undefined>(
    undefined
  );
  const [nazivUFormi, setNazivUFormi] = useState("");
  const [ProizvodjacUFormi, setProizvodjacUFormi] = useState("");
  const [PDVUFormi, setPDVUFormi] = useState<number>(0);
  const [Pretrazi, setPretraziUFormi] = useState("");
  const [izabranProizvod, setIzabranProizvod] = useState<Proizvod | undefined>(
    undefined
  );
  useEffect(() => {
    axios
      .get("http://localhost:5000/proizvod")
      .then((value) => {
        const data = value.data as Proizvod[];
        console.log(data);
        setProizvodi(data);
      })
      .catch((err) => {
        console.error(err);
      });
  }, []);
  useEffect(() => {
    axios
      .get("http://localhost:5000/proizvodjac")
      .then((value) => {
        const data = value.data as Proizvodjac[];
        setProizvodjaci(data);
        setProizvodjac(data[1]);
      })
      .catch((err) => {
        console.error(err);
      });
  }, []);

  return (
    <div>
      <label>Naziv proizvoda: </label>
      <input
        type="text"
        value={Pretrazi}
        onChange={(e) => {
          setPretraziUFormi(e.target.value);
        }}
      />
      <button
        onClick={(e) => {
          e.preventDefault();
          console.log(Pretrazi);
          axios.get("http://localhost:5000/proizvod").then((value) => {
            const data = value.data as Proizvod[];

            let p1 = data.filter((p) =>
              new RegExp(`^${Pretrazi}`).test(p.naziv)
            );
            setProizvodi(p1);
          });
        }}
      >
        Pretrazi
      </button>

      <table id="customers" className="tabela">
        <thead>
          <tr>
            <th>ID</th>
            <th>Naziv</th>
            <th>Proizvodjac</th>
            <th>PDV</th>
          </tr>
        </thead>
        <tbody>
          {(proizvodi as Proizvod[]).map((value, index) => {
            return (
              <tr key={value.id}>
                <th>{value.id}</th>
                <td>{value.naziv}</td>
                <td>{value.proiz!.naziv}</td>
                <td>{value.pdv}</td>

                <td>
                  <button
                    className="napuni"
                    onClick={() => {
                      setIzabranProizvod(value);
                      setNazivUFormi(value.naziv);
                      setPDVUFormi(value.pdv);
                      setProizvodjacUFormi(value.proiz!.naziv);
                      // selektor.querySelector(`option[value='${value.proiz.id}']`);
                    }}
                  >
                    Izmeni ili obrisi
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <div className="forma">
        <form>
          <label>Naziv: </label>
          <input
            type="text"
            value={nazivUFormi}
            onChange={(e) => {
              setNazivUFormi(e.target.value);
            }}
          />
          <label> Proizvodjac: </label>
          <select
            value={ProizvodjacUFormi}
            onChange={(e) => {
              console.log(e.target.value);

              setProizvodjacUFormi(e.target.value);
            }}
          >
            {(proizvodjaci as Proizvodjac[]).map((value, index) => {
              const data = value;
              if (data.naziv === ProizvodjacUFormi)
                return (
                  <option key={value.id} selected>
                    {data.naziv}
                  </option>
                );
              else return <option key={value.id}>{data.naziv}</option>;
            })}
          </select>
          <label> PDV: </label>
          <input
            type="number"
            value={PDVUFormi}
            onChange={(e) => {
              const broj = (e.target.value as unknown) as number;
              if (broj < 0) return;
              setPDVUFormi(broj);
            }}
          />

          <button
            onClick={(e) => {
              e.preventDefault();
              let p12 = (proizvodjaci as Proizvodjac[]).find(
                (p) => p.naziv === ProizvodjacUFormi
              );
              setProizvodjac(p12);
              console.log(p12);
              axios
                .post("http://localhost:5000/proizvod", {
                  naziv: nazivUFormi,
                  pdv: PDVUFormi,
                  proiz: proizvodjac,
                })
                .then((value) => {
                  console.log(value);
                  setProizvodi([...proizvodi, value.data as Proizvod]);
                });
            }}
          >
            Dodaj
          </button>
          <button
            disabled={!izabranProizvod}
            onClick={(e) => {
              e.preventDefault();
              console.log("Jovana");
              let p12 = (proizvodjaci as Proizvodjac[]).find(
                (p) => p.naziv === ProizvodjacUFormi
              );
              console.log({ p12: p12 });
              setProizvodjac(p12);
              console.log(p12);
              axios
                .patch(
                  "http://localhost:5000/proizvod/" + izabranProizvod!.id,
                  {
                    naziv: nazivUFormi,
                    // proizvodjac: ProizvodjacUFormi,
                    pdv: PDVUFormi,
                    proiz: p12,
                  }
                )
                .then((value) => {
                  console.log("Jovana123");
                  let p1 = (proizvodi as Proizvod[]).filter(
                    (p) => p.id !== izabranProizvod!.id
                  );
                  p1.push(value.data);
                  //  p1.sort((p1, p2) => p1.id - p2.id);

                  setProizvodi(p1);
                })
                .catch((err) => {
                  console.log(err);
                });
            }}
          >
            Izmeni
          </button>
          <button
            disabled={!izabranProizvod}
            onClick={(e) => {
              e.preventDefault();
              axios
                .delete("http://localhost:5000/proizvod/" + izabranProizvod!.id)
                .then((value) => {
                  let p1 = (proizvodi as Proizvod[]).filter(
                    (p) => p.id !== izabranProizvod!.id
                  );
                  setProizvodi(p1);
                });
            }}
          >
            Obrisi
          </button>
        </form>
      </div>
    </div>
  );
}
