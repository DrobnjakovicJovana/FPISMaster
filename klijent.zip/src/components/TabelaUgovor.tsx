import React from "react";
import { Table } from "semantic-ui-react";
import { Ugovor } from "../model/ugovor";

interface Props {
  ugovori: Ugovor[];
  izabraniUgovor: Ugovor | undefined;
  promeniUgovor: (ugovor: Ugovor) => void;
}
export default function TabelaUgovor(props: Props) {
  return (
    <Table celled selectable>
      <Table.Header>
        <Table.Row>
          <Table.HeaderCell>ID</Table.HeaderCell>
          <Table.HeaderCell>proizvod</Table.HeaderCell>
          <Table.HeaderCell>klijent</Table.HeaderCell>
          <Table.HeaderCell>datum</Table.HeaderCell>
          <Table.HeaderCell>adresa</Table.HeaderCell>
          <Table.HeaderCell>faza</Table.HeaderCell>
        </Table.Row>
      </Table.Header>
      <Table.Body>
        {props.ugovori.map((value) => {
          return (
            <Table.Row
              key={value.id!}
              active={value === props.izabraniUgovor}
              onClick={(e) => {
                props.promeniUgovor(value);
              }}
            >
              <Table.Cell>{value.id}</Table.Cell>
              <Table.Cell>{value.proizvod?.naziv}</Table.Cell>
              <Table.Cell>{value.klijent?.naziv}</Table.Cell>
              <Table.Cell>
                {value.datum?.toString().substring(0, 10)}
              </Table.Cell>
              <Table.Cell>
                {value.adresa?.naziv + " " + value.adresa?.broj}
              </Table.Cell>
              <Table.Cell>
                {value.faza ? "potpisan" : "u razmatranju"}
              </Table.Cell>
            </Table.Row>
          );
        })}
      </Table.Body>
    </Table>
  );
}
