import React from "react";
import {
  Button,
  Dropdown,
  Form,
  FormField,
  Radio,
  DropdownItemProps,
  Input,
} from "semantic-ui-react";
import { Adresa } from "../model/Adresa";
import { Drzava } from "../model/Drzava";
import { Klijent } from "../model/Klijent";
import Cookie from 'js-cookie'
import { Mesto } from "../model/Mesto";
import { Proizvod } from "../model/Proizvod";
import { Proizvodjac } from "../model/Proizvodjac";
import { Ugovor } from "../model/ugovor";
import { gql, useLazyQuery } from '@apollo/client'
import { refresh } from "../util";
interface Props {
  ugovor?: Ugovor;
  setKlijent?: (klijent: Klijent) => void;
  setAdresa?: (a: Adresa) => void;
  setProizvod?: (proizvod: Proizvod) => void;
  potpisan: boolean;
  setDatum?: (datum: Date) => void;
  setPotpisan: (potpisan: boolean) => void;
  onIzmeni?: (
    id: number,
    klijent: Klijent,
    proizvod: Proizvod,
    faza: boolean,
    datum: Date,
    adresa: Adresa
  ) => void;
  onObrisi?: () => void;
}

const FETCH = gql`
  query fetch{
    proizvodi{
        id,
        naziv,
        pdv,
        proiz{
          id,
        naziv
        }
      },
    adrese{
      id,
      naziv,
      broj,
      mesto{
        id,
        naziv,
        drzava{
          id,
          naziv
        }
      }
    },
    drzave{
      id,
      naziv
    },
    mesta{
        id,
        naziv,
        drzava{
          id,
          naziv
        }
      },
      klijenti{
        id,
        naziv
      }
  }

`

export default function FormaUgovor(props: Props) {
  const [klijenti, setKlijenti] = React.useState<Klijent[]>([]);
  const [proizvodi, setProizvodi] = React.useState<Proizvod[]>([]);
  const [drzave, setDrzave] = React.useState<Drzava[]>([]);
  const [mesta, setMesta] = React.useState<Mesto[]>([]);
  const [adrese, setAdrese] = React.useState<Adresa[]>([]);
  const [getData, { data, error }] = useLazyQuery(FETCH);
  const [datum, setDatum] = React.useState<Date | undefined>(undefined);
  const [selektovanaDrzava, setSelektovanaDrzava] = React.useState<
    Drzava | undefined
  >(undefined);
  const [selektovanoMesto, setSelektovanoMesto] = React.useState<
    Mesto | undefined
  >(undefined);
  const [selektovaniKlijent, setSelektovaniKlijent] = React.useState<
    Klijent | undefined
  >(undefined);
  const [selektovaniProizvod, setSelektovaniProizvod] = React.useState<
    Proizvod | undefined
  >(undefined);
  const [selektovanaAdresa, setSelektovanaAdresa] = React.useState<
    Adresa | undefined
  >(undefined);
  const [selektovanaFaza, setSelektovanaFaza] = React.useState<
    boolean | undefined
  >(undefined);
  const filtrirajMesta = () => {
    return mesta.filter((element) => {
      return !selektovanaDrzava || element.drzava.id === selektovanaDrzava.id;
    });
  };

  const filtrirajAdrese = () => {
    return adrese.filter((element) => {
      return !selektovanoMesto || element.mesto.id === selektovanoMesto.id;
    });
  };


  React.useEffect(() => {
    refresh(async () => {
      getData({
        context: {
          headers: {
            authorization: 'Bearer ' + Cookie.get('ACCESS_TOKEN')
          },
        }
      });
    })

  }, [])

  React.useEffect(() => {
    if (!data) {
      return;
    }
    const klijenti = data.klijenti;
    const adrese = data.adrese;
    const mesta = data.mesta;
    const drzave = data.drzave;
    const proizvodi = data.proizvodi;
    let u = (klijenti as Klijent[]).map(
      (klijent): Klijent => {
        return {
          id: klijent?.id || -1,
          naziv: klijent?.naziv || "",
        };
      }
    );

    setKlijenti(u);

    let pr = (proizvodi as Proizvod[]).map(
      (proizvod): Proizvod => {
        return {
          id: proizvod?.id || -1,
          naziv: proizvod?.naziv || "",
          pdv: proizvod?.pdv || 0,
          proiz: new Proizvodjac(proizvod!.proiz!.id, proizvod!.proiz!.naziv),
        };
      }
    );
    setProizvodi(pr);

    let dr = (drzave as Drzava[]).map(
      (drzava): Drzava => {
        return {
          id: drzava?.id || -1,
          naziv: drzava?.naziv || "",
        };
      }
    );
    setDrzave(dr);

    let mes = (mesta as Mesto[]).map(
      (mesto): Mesto => {
        return {
          id: mesto?.id || -1,
          naziv: mesto?.naziv || "",
          drzava: new Drzava(mesto.drzava.id, mesto.drzava.naziv),
        };
      }
    );
    setMesta(mes);


    let adr = (adrese as Adresa[]).map(
      (adresa): Adresa => {
        return {
          id: adresa?.id || -1,
          naziv: adresa?.naziv || "",
          broj: adresa?.broj || -1,
          mesto: new Mesto(
            adresa.mesto.id,
            adresa.mesto.naziv,
            new Drzava(adresa.mesto.drzava.id, adresa.mesto.drzava.naziv)
          ),
        };
      }
    );
    setAdrese(adr);


  }, [data])


  return (
    <Form size="large">
      {props.ugovor && <Input disabled value={props.ugovor.id} fluid />}
      <Dropdown
        placeholder="Izaberite klijenta"
        search
        fluid
        required
        selection
        value={
          (selektovaniKlijent && selektovaniKlijent.id) ||
          (props.ugovor && props.ugovor.klijent?.id)
        }
        options={klijenti.map(
          (value): DropdownItemProps => {
            return {
              text: value.naziv,
              active: props.ugovor && props.ugovor.klijent?.id === value.id,
              value: value.id,
              key: value.id,
            };
          }
        )}
        onChange={(e, data) => {
          let pom = klijenti.find(
            (pomKlijent) => pomKlijent.id === data.value
          ) as Klijent;
          setSelektovaniKlijent(pom);
          if (props.setKlijent) {
            props.setKlijent(pom);
          }
        }}
      />
      <Dropdown
        required
        placeholder="Izaberite proizvod"
        search

        fluid
        selection
        value={
          (selektovaniProizvod && selektovaniProizvod.id) ||
          (props.ugovor && props.ugovor.proizvod?.id)
        }
        options={proizvodi.map(
          (value): DropdownItemProps => {
            return {
              text: value.naziv,
              value: value.id,
              key: value.id,
            };
          }
        )}
        onChange={(e, data) => {
          let pom = proizvodi.find(
            (pomProizvod) => pomProizvod.id === data.value
          ) as Proizvod;
          setSelektovaniProizvod(pom);
          if (props.setProizvod) {
            props.setProizvod(pom);
          }
        }}
      />
      <Form.Field required>
        <Radio
          label="potpisan"
          checked={
            selektovanaFaza !== undefined
              ? selektovanaFaza
              : (props.ugovor && props.ugovor.faza) || props.potpisan
          }
          onClick={(e) => {
            setSelektovanaFaza(true);
            props.setPotpisan(true);
          }}
        />
      </Form.Field>
      <Form.Field>
        <Radio
          label="u razmatranju"
          checked={
            !(selektovanaFaza !== undefined
              ? selektovanaFaza
              : (props.ugovor && props.ugovor.faza) || props.potpisan)
          }
          onClick={(e) => {
            setSelektovanaFaza(false);
            props.setPotpisan(false);
          }}
        />
      </Form.Field>
      <Form.Input
        type="date"
        value={
          datum
            ? datum.toISOString().substr(0, 10)
            : props.ugovor && props.ugovor.datum?.toISOString().substr(0, 10)
        }
        onChange={(e, data) => {
          console.log(data.value);
          setDatum(new Date(data.value));
          if (props.setDatum) {
            props.setDatum(new Date(data.value));
            console.log(data.value);
          }
        }}
      />
      <FormField inline>
        <Dropdown
          selection
          search
          placeholder="Drzava"
          inline
          value={
            (selektovanaDrzava && selektovanaDrzava.id) ||
            (props.ugovor && props.ugovor.adresa?.mesto.drzava?.id)
          }
          onChange={(event, data) => {
            console.log(data.value);
            //sada treba da prodjem kroz listu mesta i vidim data.value sa kojim se idem pokrala
            let pom = drzave.find(
              (pomDrzava) => pomDrzava.id === data.value
            ) as Drzava;

            setSelektovanaDrzava(pom);
          }}
          options={drzave.map(
            (element): DropdownItemProps => {
              return {
                value: element.id,
                text: element.naziv,
              };
            }
          )}
        />
        <Dropdown
          selection
          search
          placeholder="Mesto"
          inline
          value={
            (selektovanoMesto && selektovanoMesto.id) ||
            (props.ugovor && props.ugovor.adresa?.mesto.id)
          }
          onChange={(event, data) => {
            console.log(data.value);
            //sada treba da prodjem kroz listu mesta i vidim data.value sa kojim se idem pokrala
            let pom = mesta.find((pomMesto) => pomMesto.id === data.value);

            setSelektovanoMesto(pom);
          }}
          options={filtrirajMesta().map(
            (element): DropdownItemProps => {
              return {
                value: element.id,
                text: element.naziv,
              };
            }
          )}
        />{" "}
        <Dropdown
          selection
          search
          placeholder="Adresa"
          inline
          value={
            (selektovanaAdresa && selektovanaAdresa.id) ||
            (props.ugovor && props.ugovor.adresa?.id)
          }
          onChange={(event, data) => {
            console.log(data.value);
            //sada treba da prodjem kroz listu mesta i vidim data.value sa kojim se idem pokrala
            let pom = adrese.find(
              (pomAdresa) => pomAdresa.id === data.value
            ) as Adresa;
            if (props.setAdresa) {
              props.setAdresa(pom);
              console.log(pom.id + "PROPS za adresu");
            }
            setSelektovanaAdresa(pom);
          }}
          options={filtrirajAdrese().map(
            (element): DropdownItemProps => {
              return {
                value: element.id,
                text: element.naziv,
              };
            }
          )}
        />
      </FormField>
      {props.ugovor && (
        <>
          <Button
            onClick={(e) => {
              e.preventDefault();
              props.onIzmeni!(
                props.ugovor!.id!,
                selektovaniKlijent
                  ? selektovaniKlijent
                  : props.ugovor?.klijent!,
                selektovaniProizvod
                  ? selektovaniProizvod
                  : props.ugovor?.proizvod!,
                selektovanaFaza !== undefined
                  ? selektovanaFaza
                  : props.ugovor?.faza!,
                datum ? datum : props.ugovor?.datum!,
                selektovanaAdresa ? selektovanaAdresa : props.ugovor?.adresa!
              );
            }}
          >
            Izmeni
          </Button>
          <Button
            onClick={(e) => {
              e.preventDefault();
              props.onObrisi!();
            }}
          >
            {" "}
            Obrsi
          </Button>
        </>
      )}
    </Form>
  );
}
