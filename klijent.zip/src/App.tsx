import React, { useEffect, useState } from 'react';
import './App.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Header from './components/Header';
import ProizvodStrana from './components/ProizvodPage';
import UgovorStrana from './components/UgovorPage'
import { User } from './model/User';
import axios from 'axios';
import Cookie from 'js-cookie'
import Register from './components/Register';
import Login from './components/Login';
function App() {

  const [user, setUser] = useState<User | undefined>(undefined);

  useEffect(() => {
    (async function () {
      const refresh_token = Cookie.get('REFRESH_TOKEN');

      try {
        const result = await axios.post('http://localhost:4000/token', {
          token: refresh_token
        });

        setUser(result.data.user);
        const access_token = result.data.access_token;
        Cookie.set('ACCESS_TOKEN', access_token);
        axios.defaults.headers['authorization'] = 'Bearer ' + access_token;
      } catch (error) {
        for (let key in error) {
          console.log(error.response)
        }
      }
    })();

  }, [])

  return (
    <Router>
      <Header user={user} onLogout={() => {
        Cookie.remove('REFRESH_TOKEN');
        Cookie.remove('ACCESS_TOKEN');
        setUser(undefined);
      }} />


      {
        user ? (
          <Switch>
            <Route path='/proizvod' >
              <ProizvodStrana />
            </Route>
            <Route path='/ugovor' >
              <UgovorStrana />
            </Route>

          </Switch>
        ) : (
          <Switch>
            <Route path='/register' >
              <Register setUser={setUser} />
            </Route>
            <Route path='/' >
              <Login setUser={setUser} />
            </Route>

          </Switch>
        )
      }
    </Router>
  );
}

export default App;
