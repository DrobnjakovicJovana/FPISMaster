import axios from "axios";
import Cookie from "js-cookie";

export const refresh = async (f: any) => {
  const refresh_token = Cookie.get("REFRESH_TOKEN");
  const result = await axios.post("http://localhost:4000/token", {
    token: refresh_token,
  });

  const access_token = result.data.access_token;
  Cookie.set("ACCESS_TOKEN", access_token);
  return f({
    headers: {
      authorization: "Bearer " + access_token,
    },
  });
};
