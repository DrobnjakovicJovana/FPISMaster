import { Router } from "express";
import { getRepository } from "typeorm";

import Adresa from "../entity/adresa";

const router = Router();

router.get("/", (req, res) => {
  getRepository(Adresa)
    .find()
    .then((adresa) => {
      res.json(adresa);
    });
});

export default router;
