import { Router } from "express";
import { getRepository } from "typeorm";
import Proizvod from "../entity/proizvod";

const router = Router();

router.get("/p/:pretraga", (req, res) => {
  console.log(req.params.naziv);
  getRepository(Proizvod)
    .find({
      where: { naziv: req.params.pretraga },
    })
    .then((proizvodi) => {
      res.json(proizvodi);
    });
});

router.get("/", (req, res) => {
  getRepository(Proizvod)
    .find()
    .then((proizvodi) => {
      res.json(proizvodi);
    });
});
router.get("/:id", (req, res) => {
  getRepository(Proizvod)
    .findOne(req.params.id)
    .then((proizvod) => {
      res.json(proizvod);
    });
});
router.post("/", (req, res) => {
  //validacija
  console.log(req.params.proiz);
  getRepository(Proizvod)
    .insert(req.body)
    .then((value) => {
      res.json({ ...req.body, id: value.identifiers[0].id });
    })
    .catch((err) => console.log(err));
});
router.delete("/:id", (req, res) => {
  getRepository(Proizvod)
    .delete(req.params.id)
    .then((value) => {
      res.json({ status: 200 });
    });
});

router.patch("/:id", (req, res) => {
  getRepository(Proizvod)
    .update(req.params.id, req.body)
    .then((value) => {
      return getRepository(Proizvod).findOne(req.params.id);
    })
    .then((value) => {
      res.json(value);
    });
});

export default router;
