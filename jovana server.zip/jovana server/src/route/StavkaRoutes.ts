import { Router } from "express";
import { getRepository } from "typeorm";

import StavkaUgovora from "../entity/stavkaUgovora";

const router = Router();

router.post("/", (req, res) => {
  //validacija
  console.log("post stavka");
  getRepository(StavkaUgovora)
    .insert(req.body)
    .then((value) => {
      res.json({ ...req.body, id: value.identifiers[0].id });
    })
    .catch((error) => res.json(error));
});

router.delete("/:id", (req, res) => {
  getRepository(StavkaUgovora)
    .delete(req.params.id)
    .then((value) => {
      res.json({ status: 200 });
    });
});

router.patch("/:id", (req, res) => {
  getRepository(StavkaUgovora)
    .update(req.params.id, req.body)
    .then((value) => {
      return getRepository(StavkaUgovora).findOne(req.params.id);
    })
    .then((value) => {
      res.json(value);
    });
});
router.get("/", (req, res) => {
  getRepository(StavkaUgovora)
    .find()
    .then((ugovori) => {
      res.json(ugovori);
    });
});

export default router;
