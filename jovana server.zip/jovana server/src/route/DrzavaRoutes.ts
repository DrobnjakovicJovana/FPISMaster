import { Router } from "express";
import { getRepository } from "typeorm";

import Drzava from "../entity/drzava";
const router = Router();

router.get("/", (req, res) => {
  getRepository(Drzava)
    .find()
    .then((drzave) => {
      res.json(drzave);
    });
});

export default router;
