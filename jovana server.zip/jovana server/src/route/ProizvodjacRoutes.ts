import { Router } from "express";
import { getRepository } from "typeorm";

import Proizvodjac from "../entity/proizvodjac";
import Proizvod from "../entity/proizvod";
const router = Router();

router.get("/", (req, res) => {
  getRepository(Proizvodjac)
    .find()
    .then((proizvodjaci) => {
      res.json(proizvodjaci);
    });
});

export default router;
