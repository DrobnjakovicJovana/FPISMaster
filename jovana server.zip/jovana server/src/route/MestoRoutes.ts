import { Router } from "express";
import { getRepository } from "typeorm";

import Mesto from "../entity/mesto";

const router = Router();

router.get("/", (req, res) => {
  getRepository(Mesto)
    .find()
    .then((mesta) => {
      res.json(mesta);
    });
});

export default router;
