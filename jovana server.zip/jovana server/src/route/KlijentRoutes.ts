import { Router } from "express";
import { getRepository } from "typeorm";

import Klijent from "../entity/klijent";

const router = Router();

router.get("/", (req, res) => {
  getRepository(Klijent)
    .find()
    .then((klijenti) => {
      res.json(klijenti);
    });
});

export default router;
