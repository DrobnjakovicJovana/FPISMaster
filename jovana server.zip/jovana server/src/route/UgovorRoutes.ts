import { Router } from "express";
import { getRepository, FindConditions } from "typeorm";
import Ugovor from "../entity/ugovor";
import StavkaUgovora from "../entity/stavkaUgovora";

const router = Router();

router.get("/", (req, res) => {
  getRepository(Ugovor)
    .find()
    .then((ugovori) => {
      res.json(ugovori);
    });
});
router.get("/:id", (req, res) => {
  getRepository(Ugovor)
    .findOne(req.params.id)
    .then((ugovor) => {
      res.json(ugovor);
    });
});
router.post("/", (req, res) => {
  //validacija
  console.log("post ugovor");

  getRepository(Ugovor)
    .insert(req.body)
    .then((value) => {
      res.json({ ...req.body, id: value.identifiers[0].id });
    })
    .catch((error) => res.json(error));
});
router.delete("/:id", (req, res) => {
  getRepository(Ugovor)
    .delete(req.params.id)
    .then((value) => {
      res.json({ status: 200 });
    })
    .catch((error) => res.json(error));
});

router.patch("/:id", (req, res) => {
  let { stavke, ...ugovor } = req.body as Ugovor;
  getRepository(Ugovor)
    .update(req.params.id, ugovor)
    .then((value) => {
      let stavkeZaInsert = stavke.filter(
        (element) => !element.id && !element.obrisana && element.promenjena
      );
      console.log(stavkeZaInsert);
      return getRepository(StavkaUgovora).insert(stavkeZaInsert);
    })
    .then((value) => {
      let stavkeZaBrisanje = stavke.filter(
        (element) => element.id && element.obrisana && element.promenjena
      );
      return Promise.all(
        stavkeZaBrisanje.map((stavka) => {
          const cond: FindConditions<StavkaUgovora> = {
            id: stavka.id,
            ugovor: {
              id: parseInt(req.params.id),
            },
          };
          return getRepository(StavkaUgovora).delete(cond);
        })
      );
    })
    .then((value) => {
      let stavkeZaIzmenu = stavke.filter(
        (element) => !element.obrisana && element.id && !element.promenjena
      );
      return Promise.all(
        stavkeZaIzmenu.map((stavka) => {
          const cond: FindConditions<StavkaUgovora> = {
            id: stavka.id,
            ugovor: {
              id: parseInt(req.params.id),
            },
          };
          const { ugovor, obrisana, ...st } = stavka;
          console.log("CONDITION IS " + cond);
          return getRepository(StavkaUgovora).update(cond, {
            opis: stavka.opis,
          });
        })
      );
    })
    .then((value) => {
      value.forEach((element) => console.log(element));
      return getRepository(Ugovor).findOne(req.params.id);
    })
    .then((value) => {
      ugovor = value!;
      return getRepository(StavkaUgovora)
        .find({
          where: {
            ugovor: {
              id: req.params.id,
            },
          },
          select: ["id", "opis"],
        })
        .then((value) => {
          stavke = value;
          res.json(ugovor);
        });
    })
    .catch((err) => {
      res.json(err);
    });
});

export default router;
