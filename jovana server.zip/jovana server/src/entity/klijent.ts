import {
  Column,
  PrimaryGeneratedColumn,
  Entity,
  ManyToOne,
  OneToMany,
} from "typeorm";
import Adresa from "./adresa";
import Ugovor from "./ugovor";

@Entity()
class Klijent {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  naziv: string;

  @ManyToOne((type) => Adresa, (p) => p.klijenti, {
    eager: true,
  })
  adresa: Adresa;

  @OneToMany((type) => Ugovor, (p) => p.klijent, {
    eager: false,
  })
  ugovori: Ugovor[];

  constructor(id: number, naziv: string, adresa: Adresa, ugovori: Ugovor[]) {
    this.id = id;
    this.naziv = naziv;
    this.adresa = adresa;
    this.ugovori = ugovori;
  }
}

export default Klijent;
