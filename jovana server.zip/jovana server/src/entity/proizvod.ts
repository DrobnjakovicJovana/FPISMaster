import { Column, PrimaryGeneratedColumn, Entity, ManyToOne } from "typeorm";
import Proizvodjac from "./proizvodjac";

@Entity()
class Proizvod {
  @PrimaryGeneratedColumn()
  private id: number;

  @Column()
  private naziv: string;

  @Column()
  private pdv: number;

  @ManyToOne((type) => Proizvodjac, (p) => p.proizvodi, {
    eager: true,
  })
  proiz: Proizvodjac;

  constructor(id: number, naziv: string, pdv: number, proiz: Proizvodjac) {
    this.id = id;
    this.naziv = naziv;
    this.pdv = pdv;
    this.proiz = proiz;
  }
}

export default Proizvod;
