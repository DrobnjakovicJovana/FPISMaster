import {
  Column,
  PrimaryGeneratedColumn,
  Entity,
  ManyToOne,
  OneToMany,
} from "typeorm";
import Mesto from "./mesto";
import Proizvodjac from "./proizvodjac";
import Klijent from "./klijent";

@Entity()
class Adresa {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  naziv: string;

  @Column()
  broj: string;

  @ManyToOne((type) => Mesto, (p) => p.adrese, { eager: true, primary: true })
  mesto: Mesto;
  @OneToMany((type) => Proizvodjac, (p) => p.adresa, {
    eager: false,
  })
  proizvodjaci: Proizvodjac[];
  @OneToMany((type) => Klijent, (k) => k.adresa, {
    eager: false,
  })
  klijenti: Klijent[];
  constructor(
    id: number,
    naziv: string,
    proizvodjaci: Proizvodjac[],
    klijenti: Klijent[],
    broj: string,
    mesto: Mesto
  ) {
    this.id = id;
    this.proizvodjaci = proizvodjaci;
    this.klijenti = klijenti;
    this.broj = broj;
    this.naziv = naziv;
    this.mesto = mesto;
  }
}

export default Adresa;
