import { Column, PrimaryGeneratedColumn, Entity, ManyToOne } from "typeorm";

import Ugovor from "./ugovor";

@Entity()
class StavkaUgovora {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  opis: string;

  @ManyToOne((type) => Ugovor, (p) => p.stavke, {
    eager: false,
    onDelete: "CASCADE",
  })
  ugovor: Ugovor;

  obrisana: boolean;
  promenjena: boolean;
  constructor(id: number, opis: string, ugovor: Ugovor) {
    this.id = id;
    this.opis = opis;
    this.ugovor = ugovor;
    this.obrisana = false;
    this.promenjena = false;
  }
}

export default StavkaUgovora;
