import {
  Column,
  PrimaryGeneratedColumn,
  Entity,
  ManyToOne,
  OneToMany,
} from "typeorm";
import Drzava from "./drzava";
import Adresa from "./adresa";

@Entity()
class Mesto {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  naziv: string;

  @ManyToOne((type) => Drzava, (p) => p.mesta, { eager: true })
  drzava: Drzava;
  @OneToMany((type) => Adresa, (p) => p.mesto, {
    eager: false,
  })
  adrese: Adresa[];

  constructor(id: number, naziv: string, drzava: Drzava, adrese: Adresa[]) {
    this.id = id;
    this.naziv = naziv;
    this.drzava = drzava;
    this.adrese = adrese;
  }
}

export default Mesto;
