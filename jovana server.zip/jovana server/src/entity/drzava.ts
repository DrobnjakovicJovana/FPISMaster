import { Column, PrimaryGeneratedColumn, Entity, OneToMany } from "typeorm";
import Mesto from "./mesto";

@Entity()
class Drzava {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  naziv: string;

  @OneToMany((type) => Mesto, (m) => m.drzava, {
    eager: false,
  })
  mesta: Mesto[];

  constructor(id: number, naziv: string, mesta: Mesto[]) {
    this.id = id;
    this.naziv = naziv;
    this.mesta = mesta;
  }
}

export default Drzava;
