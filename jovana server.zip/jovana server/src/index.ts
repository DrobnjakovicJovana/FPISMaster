import "reflect-metadata";
import { createConnection } from "typeorm";
import express from "express";
import cors from "cors";
import ProizvodRoute from "./route/ProizvodRoutes";
import UgovorRoute from "./route/UgovorRoutes";
import ProizvodjacRoute from "./route/ProizvodjacRoutes";
import DrzavaRoute from "./route/DrzavaRoutes";
import MestoRoute from "./route/MestoRoutes";
import AdresaRoute from "./route/AdresaRoutes";
import KlijentRoute from "./route/KlijentRoutes";
import StavkaRoute from "./route/StavkaRoutes";
import jwt from "jsonwebtoken";
createConnection().then((conection) => {
  const app = express();
  app.use(cors());

  app.use(express.json());

  app.use("/proizvod", ProizvodRoute);

  app.use("/proizvodjac", ProizvodjacRoute);

  app.use("/ugovor", UgovorRoute);

  app.use("/drzava", DrzavaRoute);

  app.use("/mesto", MestoRoute);

  app.use("/adresa", AdresaRoute);

  app.use("/klijent", KlijentRoute);

  app.use("/stavka", StavkaRoute);

  app.listen(5000, () => console.log("App is listening"));
});
